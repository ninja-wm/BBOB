import setuptools

setuptools.setup(
    name="BBOB",
    version="1.0.0",
    author="能断",
    author_email="2621843957@qq.com",
    description="",
    long_description="对BBOB函数的实现",
    long_description_content_type="text",
    url="",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
